<?php

return [
    'home' => 'Home',
    'about' => 'About',
    'contact' => 'Contact',
    'services' => 'Services',
    'account' => 'Account',
    'faq' => 'FAQ\'s',
    'header_title' => 'Get your appliances fixed without hassle!',
    'header_subtitle' => 'Success isn\'t always about greatness. It\'s about consistency.',
];
