
<style>/* public/css/style.css */

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #333;
    color: white;
    padding: 10px 0;
    text-align: center;
}

nav a {
    color: white;
    margin: 0 15px;
    text-decoration: none;
}

main {
    padding: 20px;
}

.about-us-container {
    max-width: 1200px;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.hero-section {
    text-align: center;
    margin-bottom: 40px;
}

.hero-section h1 {
    font-size: 36px;
}

.about-us-content h2 {
    font-size: 28px;
    margin-top: 20px;
}

.about-us-content p, ul {
    font-size: 18px;
    line-height: 1.6;
}

ul {
    list-style-type: disc;
    margin-left: 40px;
}

footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: white;
    position: fixed;
    bottom: 0;
    width: 100%;
}
</style>

<?php /**PATH D:\Xampp\htdocs\HelloFixer\resources\views/about-us.blade.php ENDPATH**/ ?>