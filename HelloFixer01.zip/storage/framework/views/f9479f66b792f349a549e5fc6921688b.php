<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Contact US'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style1.css')); ?>"> <!-- Link to your CSS -->
</head>
<body>
    <header>
        <div class="header">
            <div class="container">
                <div class="navbar">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('images/logo01.png')); ?>" alt="logo" width="110px">
                        </a>
                        <span class="site-name">HelloFixer</span>
                    </div>
                    <nav>
                        <ul id="MenuItems">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('/products')); ?>">Services</a></li>
                            <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                            <li><a href="<?php echo e(url('/account')); ?>">Account</a></li>
                        </ul>
                    </nav>
                </div> <!-- Close navbar -->
            </div> <!-- Close container -->
        </div> <!-- Close header -->
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <div class="footer">
            <div class="container">
                <p>&copy; 2024 HelloFixer. All rights reserved.</p>
                <ul class="footer-links">
                    <li><a href="<?php echo e(url('/privacy')); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo e(url('/terms')); ?>">Terms of Service</a></li>
                    <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/app1.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Xampp\htdocs\HelloFixer\resources\views/layouts/app1.blade.php ENDPATH**/ ?>